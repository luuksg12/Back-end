document.getElementById("knopje").addEventListener("mouseenter", function(){
    this.style.transform = "scale(1.5)"});
document.getElementById("knopje").addEventListener("mouseleave", function(){
    this.style.transform = "scale(1)"});