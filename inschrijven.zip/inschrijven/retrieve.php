<?php
include_once 'connect.php';
    $voornaam = $_POST['voornaam'];
    $achternaam = $_POST['achternaam'];
    $adres = $_POST['adres'];
    $woonplaats = $_POST['woonplaats'];
    $telefoonnummer = $_POST['telefoonnummer'];
    $email = $_POST['email'];
    $bericht = $_POST['bericht'];
    $date = $_POST['date'];
    $place = $_POST['place'];
