<!DOCTYPE html>
<body>
    <header>
        <link rel="stylesheet" type="text/css" href="grid.css">
        <div id = "title">
            <h1>W o r t e l K r a c h t</h1>
        </div>
        <nav>
            <div>
                <table id = "tableR">
                    <tr>
                        <td class = "td"><a class = "knop1" href="https://www.studiohertz.nl/"><p>HOME</p></a></td>
                        <td class = "td"><a class = "knop1" href="https://www.studiohertz.nl/gallery"><p>KLANKTHERAPIE</p></a></td>
                        <td class = "td"><a class = "knop1" href="https://www.studiohertz.nl/about"><p>OVER MIJ</p></a></td>
                        <td class = "td"><a class = "knop1" href="https://www.studiohertz.nl/agenda"><p>AGENDA</p></a></td>
                        <td class = "td"><a class = "knop1" href="https://www.studiohertz.nl/contact"><p>OVER MIJ</p></a></td>
                        <td class = "td"><a class = "knop1" href="http://localhost/inschrijven/"><p>INSCHRIJVEN</p></a></td>
                    </tr>
                </table>
            </div>
        </nav>
    </header>
    <nav>
        <p>links</p>

    </nav>
    <main>
        <p>rechts</p>

    </main>
    <footer>
        <p>footer</p>

    </footer>
</body>