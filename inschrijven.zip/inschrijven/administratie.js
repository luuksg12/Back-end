document.getElementById("add").addEventListener("click", function(){
    window.alert("Datum toegevoegd");
});
document.getElementById("remove").addEventListener("click", function(){
    window.alert("Datum verwijderd");
});