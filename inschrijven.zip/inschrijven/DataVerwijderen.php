<?php
include_once 'connect.php';
//Dit stuk code verwijdert data uit de database. Hiermee kan ik de verouderede datums verwijderen uit de selectbar
$datum1 = $_POST['datum1'];

$query = 'DELETE FROM `DatumLijst` WHERE datum1 = "'.$datum1.'"';

mysqli_query($connection,$query);
mysqli_close($connection);
header("location: administratie.php");