document.getElementById("testid").addEventListener("click", function inschrijf(){
    window.alert("Dankuwel voor uw inschrijving")});

