<?php

$dbServername = "localhost";
$dbUsername = "0966746";
$dbPassword = "beuyeipa";
$dbName = "0966746";

$connection = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName );

?>
