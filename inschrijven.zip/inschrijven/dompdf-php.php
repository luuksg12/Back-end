<?php
require_once 'dompdf/autoload.inc.php';
require "connect.php";

//laad de data in vanuit de database
$query = "SELECT * FROM `datumlijst` WHERE 1";
$fetchproduct = mysqli_query($connection, $query);
while ($product = mysqli_fetch_row($fetchproduct)) {
    file_put_contents("datalijst.html",$product[0],FILE_APPEND);
    file_put_contents("datalijst.html","<br>",FILE_APPEND);
}

// gebruik dompdf
use Dompdf\Dompdf;

// maak een dom pdf class
$dompdf = new Dompdf();
$dompdf->loadHtml(file_get_contents('datalijst.html'));

// settings
$dompdf->setPaper('A4', 'landscape');

// Renderen van een html naar pdf
$dompdf->render();

// Stuur de download in de browser
$dompdf->stream("inschrijf data");

//verwijder de file waarin alle data staat
unlink("datalijst.html");
?>
